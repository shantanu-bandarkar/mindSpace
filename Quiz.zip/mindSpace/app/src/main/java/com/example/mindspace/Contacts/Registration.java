package com.example.mindspace.Contacts;

public class Registration {
    private int id;
    private String name;
    private String mob;

    public void setId(int id) { this.id = id; }

    public void setName(String name) { this.name = name; }

    public void setMob(String mob) { this.mob = mob;}

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMob() {
        return mob;
    }
}
